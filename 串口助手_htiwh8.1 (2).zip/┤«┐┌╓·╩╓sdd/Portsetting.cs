﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace 串口助手sdd
{
    public partial class Portsetting : Form
    {
        public Portsetting()
        {
            InitializeComponent();
            comboBox2.Items.Add("1200");
            comboBox2.Items.Add("2400");
            comboBox2.Items.Add("4800");
            comboBox2.Items.Add("9600");
            comboBox2.Items.Add("19200");
            comboBox2.Items.Add("38400");
            comboBox2.Items.Add("43000");
            comboBox2.Items.Add("56000");
            comboBox2.Items.Add("57600");
            comboBox2.Items.Add("115200");

            comboBox5.Items.Add("1");
            comboBox5.Items.Add("1.5");
            comboBox5.Items.Add("2");

            comboBox4.Items.Add("8");
            comboBox4.Items.Add("7");
            comboBox4.Items.Add("6");
            comboBox4.Items.Add("5");

            comboBox3.Items.Add("无");
            comboBox3.Items.Add("奇校验");
            comboBox3.Items.Add("偶校验");
        }

        private void OKButton_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = (Form1)this.Owner;

            try
            {
                switch (comboBox3.Text.Trim())//设置奇偶校验位 
                {
                    case "无": form1.PortInfo.PARITY = Parity.None; break;
                    case "奇校验": form1.PortInfo.PARITY = Parity.Odd; break;
                    case "偶校验": form1.PortInfo.PARITY = Parity.Even; break;
                    default: form1.PortInfo.PARITY = Parity.None; break;
                }

                form1.PortInfo.Baudrate = Convert.ToInt32(comboBox2.Text.Trim());
                
                form1.PortInfo.DataBits = Convert.ToInt32(comboBox4.Text.Trim());

                switch (comboBox5.Text.Trim())//设置停止位
                {
                    case "1": form1.PortInfo.STOPBITS = StopBits.One; break;
                    case "1.5": form1.PortInfo.STOPBITS = StopBits.OnePointFive; break;
                    case "2": form1.PortInfo.STOPBITS = StopBits.Two; break;
                    default: form1.PortInfo.STOPBITS = StopBits.None; break;
                }
                DialogResult = DialogResult.OK;
            }
            catch (NullReferenceException)
            {
                //不理会，以后再赋给串口
            }

            this.Close();
        }

        private void cancelButton_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
