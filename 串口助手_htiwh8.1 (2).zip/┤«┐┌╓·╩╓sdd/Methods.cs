﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 串口助手sdd
{
    class Methods
    {
        //获取有效的COM口
        public static string[] ActivePorts()
        {
            ArrayList activePorts = new ArrayList();//申明有效的串口数组
            foreach (string pname in SerialPort.GetPortNames())
            {
                activePorts.Add(pname.Substring(3));//找到后存入
            }
            activePorts.Sort();//有效的串口号排序
            string[] mystr = new string[activePorts.Count];
            for ( int i=0;i<=(activePorts .Count-1);i ++)
            {
                mystr[i] = "COM" +activePorts[i];
            }
            return mystr;//放入mystr字符串中
        }

        //16进制字符串转换为byte字符数组
        public static Byte[] _16strToHex(string strValues)
        {
            string[] hexValuesSplit = strValues.Split(' ');
            Byte[] hexValues = new Byte[hexValuesSplit.Length];
            Console.WriteLine(hexValuesSplit.Length);
            for (int i = 0; i < hexValuesSplit.Length; i++)
            {
                hexValues[i] = Convert.ToByte(hexValuesSplit[i], 16);
            }
            return hexValues;
        }
        public static byte _2strToBYTE(string _2str)
        {
            byte BYTE;
            Int32 tem;
            tem = Convert.ToInt32(_2str) + 11;
            BYTE = Convert.ToByte (tem / 10 * 16 + tem % 10);
            return BYTE;
        }
        

        //byte数组以16进制形式转字符串
        public static string ByteTo16Str(byte[] bytes)
        {
            string recData = null;//创建接收数据的字符串
            foreach (byte outByte in bytes)//将字节数组以16进制形式遍历到一个字符串内
            {
                recData += outByte.ToString("X2") + " ";
            }
            return recData;
        }

        public  static byte[] senser_zhen_tran(byte [] ReceivedData_jieshou)
        {
            int  i = 0;
            Byte  _cnt = 0;
            Byte  sum=0;
            
            byte[] senser_zhen = new byte[23];
            byte[] data_to_send = new byte[23];

            data_to_send[_cnt++]=0xAA;
            data_to_send[_cnt++]=0xAA;
            data_to_send[_cnt++]=0x02;
            data_to_send[_cnt++]=0x12;

            data_to_send[_cnt++] = ReceivedData_jieshou[22];
            data_to_send[_cnt++] = ReceivedData_jieshou[23];
            data_to_send[_cnt++] = ReceivedData_jieshou[24];
            data_to_send[_cnt++] = ReceivedData_jieshou[25];
            data_to_send[_cnt++] = ReceivedData_jieshou[26];
            data_to_send[_cnt++] = ReceivedData_jieshou[27];

            data_to_send[_cnt++] = ReceivedData_jieshou[28];
            data_to_send[_cnt++] = ReceivedData_jieshou[29];
            data_to_send[_cnt++] = ReceivedData_jieshou[30];
            data_to_send[_cnt++] = ReceivedData_jieshou[31];
            data_to_send[_cnt++] = ReceivedData_jieshou[32];
            data_to_send[_cnt++] = ReceivedData_jieshou[33];
            data_to_send[_cnt++]=0;
            data_to_send[_cnt++]=0;
            data_to_send[_cnt++]=0;
            data_to_send[_cnt++]=0;
            data_to_send[_cnt++]=0;
            data_to_send[_cnt++]=0; 
            //和校验 
            for (i = 0; i < _cnt; i++)
            {
                sum += data_to_send[i];
            }

            data_to_send[_cnt++] = sum;

            //串口发送数据
            for (i = 0; i < _cnt; i++)
            {
                senser_zhen[i]=data_to_send[i];
            }   
            return senser_zhen;
        }


        //提取加速度或角度信息，
        internal static object byteTo_acc_ang(byte[] receivedData, bool flag, int xishu1, int xishu2)
        {            
            double acc_ang_double;
            int  temp;
            if (flag)//1：计算加速度
            {
                temp = receivedData[xishu1] * 256 +receivedData[xishu2];//将两个系数位的数合成为一个十六进制，再转为十进制
                if ((temp >> 15) == 1)//如果符号位、最高位为1，则将补码转化为原码，否则不变
                {
                    temp = temp - 1;
                    temp = (~temp)^0xffff*(-1);
                }                   
                acc_ang_double= (Convert.ToDouble (temp)/16384)*9.8;//根据最小精度换算，单位为m/s²
            }
            else//0计算角度
            {
                temp = receivedData[xishu1] * 256 + receivedData[xishu2];//将两个系数位的数合成为一个十六进制，再转为十进制
                if ((temp >> 15) == 1)//如果符号位、最高位为1，则将补码转化为原码，否则不变
                {
                    temp = temp - 1;
                    temp = (~temp) ^ 0xffff * (-1);
                }
                acc_ang_double = Convert.ToDouble(temp)  / 131;//根据最小精度换算，单位为°
            }
            return acc_ang_double;
        }
    }
}
