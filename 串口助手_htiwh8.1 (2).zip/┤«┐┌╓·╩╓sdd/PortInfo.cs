﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;

namespace 串口助手sdd
{
    public class PortInfo
    {
        //Private member variables
        private int baudrate;
        private int dataBits;
        private Parity parity;
        private StopBits stopBits;

        //Public property
      
        public int Baudrate
        {
            get { return baudrate; }
            set { baudrate = value; }
        }
        public int DataBits
        {
            get { return dataBits; }
            set { dataBits = value; }
        }
        public Parity PARITY
        {
            get { return parity; }
            set { parity = value; }
        }
        public StopBits STOPBITS
        {
            get { return stopBits; }
            set { stopBits = value; }
        }

       
        public PortInfo(int br = 9600,
                        int db = 8,
                        Parity p = Parity.None,
                        StopBits sb = StopBits.One
                         )
        {
            baudrate = br;
            dataBits = db;
            parity = p;
            stopBits = sb;
           
        }
    }
}
