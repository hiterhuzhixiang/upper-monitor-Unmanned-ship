﻿using System;

namespace 串口助手sdd
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.recCOMPort = new System.Windows.Forms.ComboBox();
            this.cbxCOMPort = new System.Windows.Forms.ComboBox();
            this.btnOpenCom = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label39 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.freshbutton = new System.Windows.Forms.Button();
            this.setbutton = new System.Windows.Forms.Button();
            this.btnClearCount = new System.Windows.Forms.Button();
            this.tbReceivedCount = new System.Windows.Forms.TextBox();
            this.tbSendCount = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.zhilingCOMPort = new System.Windows.Forms.ComboBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnSaveFile = new System.Windows.Forms.Button();
            this.btnClearReceived = new System.Windows.Forms.Button();
            this.cb16Display = new System.Windows.Forms.CheckBox();
            this.tbReceivedData = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btnReadFile = new System.Windows.Forms.Button();
            this.cb16Send = new System.Windows.Forms.CheckBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.btnClearSend = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.tbSpaceTime = new System.Windows.Forms.TextBox();
            this.cbAutomaticSend = new System.Windows.Forms.CheckBox();
            this.tbSendData = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.zitaiCOMPort = new System.Windows.Forms.ComboBox();
            this.zitaiSendCount = new System.Windows.Forms.TextBox();
            this.zitaiSendData = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.zitaiClearData = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.hangxiang = new System.Windows.Forms.TextBox();
            this.jingjie_d = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.qian_distance = new System.Windows.Forms.TextBox();
            this.weidu = new System.Windows.Forms.TextBox();
            this.jingdu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.temperature = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.angle3 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.angle2 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.angle1 = new System.Windows.Forms.TextBox();
            this.acceleration3 = new System.Windows.Forms.TextBox();
            this.acceleration2 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.acceleration1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.right_distance = new System.Windows.Forms.TextBox();
            this.left_distance = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label57 = new System.Windows.Forms.Label();
            this.duzhiling_jiange = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label51 = new System.Windows.Forms.Label();
            this.sd_SpaceTime = new System.Windows.Forms.TextBox();
            this.sd_AutomaticSend = new System.Windows.Forms.CheckBox();
            this.shoudong_ctrl = new System.Windows.Forms.CheckBox();
            this.label40 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.right_dangwei = new System.Windows.Forms.TextBox();
            this.left_dangwei = new System.Windows.Forms.TextBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.shipin_ctrl = new System.Windows.Forms.CheckBox();
            this.zhiling_jieshou_count = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.zhiling_clear = new System.Windows.Forms.Button();
            this.hong_zhiling = new System.Windows.Forms.TextBox();
            this.zhiling_list = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.videoSourcePlayer = new AForge.Controls.VideoSourcePlayer();
            this.Photograph = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.label45 = new System.Windows.Forms.Label();
            this.tscbxCameras = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.jianru_xilie = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.xiliezhiling = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.zhiling_jiange = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label41 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // recCOMPort
            // 
            this.recCOMPort.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.recCOMPort.FormattingEnabled = true;
            this.recCOMPort.Location = new System.Drawing.Point(82, 130);
            this.recCOMPort.Name = "recCOMPort";
            this.recCOMPort.Size = new System.Drawing.Size(59, 20);
            this.recCOMPort.TabIndex = 11;
            // 
            // cbxCOMPort
            // 
            this.cbxCOMPort.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.cbxCOMPort.ForeColor = System.Drawing.SystemColors.WindowText;
            this.cbxCOMPort.FormattingEnabled = true;
            this.cbxCOMPort.Location = new System.Drawing.Point(82, 94);
            this.cbxCOMPort.Name = "cbxCOMPort";
            this.cbxCOMPort.Size = new System.Drawing.Size(59, 20);
            this.cbxCOMPort.TabIndex = 5;
            // 
            // btnOpenCom
            // 
            this.btnOpenCom.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnOpenCom.Location = new System.Drawing.Point(151, 94);
            this.btnOpenCom.Name = "btnOpenCom";
            this.btnOpenCom.Size = new System.Drawing.Size(65, 23);
            this.btnOpenCom.TabIndex = 10;
            this.btnOpenCom.Text = "打开串口";
            this.btnOpenCom.UseVisualStyleBackColor = false;
            this.btnOpenCom.Click += new System.EventHandler(this.btnOpenCom_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox2.Controls.Add(this.label39);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.freshbutton);
            this.groupBox2.Controls.Add(this.setbutton);
            this.groupBox2.Controls.Add(this.btnClearCount);
            this.groupBox2.Controls.Add(this.tbReceivedCount);
            this.groupBox2.Controls.Add(this.btnOpenCom);
            this.groupBox2.Controls.Add(this.tbSendCount);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.cbxCOMPort);
            this.groupBox2.Controls.Add(this.recCOMPort);
            this.groupBox2.Location = new System.Drawing.Point(0, 10);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(228, 194);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "计数";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(11, 133);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(65, 12);
            this.label39.TabIndex = 56;
            this.label39.Text = "接收串口号";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 12);
            this.label1.TabIndex = 55;
            this.label1.Text = "发送串口号";
            // 
            // freshbutton
            // 
            this.freshbutton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.freshbutton.Location = new System.Drawing.Point(151, 128);
            this.freshbutton.Name = "freshbutton";
            this.freshbutton.Size = new System.Drawing.Size(65, 23);
            this.freshbutton.TabIndex = 13;
            this.freshbutton.Text = "刷新";
            this.freshbutton.UseVisualStyleBackColor = false;
            this.freshbutton.Click += new System.EventHandler(this.freshbutton_Click);
            // 
            // setbutton
            // 
            this.setbutton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.setbutton.Location = new System.Drawing.Point(82, 165);
            this.setbutton.Name = "setbutton";
            this.setbutton.Size = new System.Drawing.Size(65, 23);
            this.setbutton.TabIndex = 12;
            this.setbutton.Text = "设置";
            this.setbutton.UseVisualStyleBackColor = false;
            this.setbutton.Click += new System.EventHandler(this.setbutton_Click);
            // 
            // btnClearCount
            // 
            this.btnClearCount.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClearCount.Location = new System.Drawing.Point(153, 52);
            this.btnClearCount.Name = "btnClearCount";
            this.btnClearCount.Size = new System.Drawing.Size(63, 23);
            this.btnClearCount.TabIndex = 4;
            this.btnClearCount.Text = "清空计数";
            this.btnClearCount.UseVisualStyleBackColor = false;
            this.btnClearCount.Click += new System.EventHandler(this.btnClearCount_Click);
            // 
            // tbReceivedCount
            // 
            this.tbReceivedCount.BackColor = System.Drawing.Color.White;
            this.tbReceivedCount.Location = new System.Drawing.Point(82, 54);
            this.tbReceivedCount.Name = "tbReceivedCount";
            this.tbReceivedCount.Size = new System.Drawing.Size(65, 21);
            this.tbReceivedCount.TabIndex = 3;
            // 
            // tbSendCount
            // 
            this.tbSendCount.BackColor = System.Drawing.Color.White;
            this.tbSendCount.Location = new System.Drawing.Point(6, 54);
            this.tbSendCount.Name = "tbSendCount";
            this.tbSendCount.Size = new System.Drawing.Size(63, 21);
            this.tbSendCount.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(82, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(65, 12);
            this.label8.TabIndex = 1;
            this.label8.Text = "接收(byte)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 12);
            this.label7.TabIndex = 0;
            this.label7.Text = "发送(byte)";
            // 
            // zhilingCOMPort
            // 
            this.zhilingCOMPort.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.zhilingCOMPort.FormattingEnabled = true;
            this.zhilingCOMPort.Location = new System.Drawing.Point(101, 25);
            this.zhilingCOMPort.Name = "zhilingCOMPort";
            this.zhilingCOMPort.Size = new System.Drawing.Size(59, 20);
            this.zhilingCOMPort.TabIndex = 14;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox3.Controls.Add(this.btnSaveFile);
            this.groupBox3.Controls.Add(this.btnClearReceived);
            this.groupBox3.Controls.Add(this.cb16Display);
            this.groupBox3.Controls.Add(this.tbReceivedData);
            this.groupBox3.Location = new System.Drawing.Point(0, 212);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(228, 173);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "数据接收区";
            // 
            // btnSaveFile
            // 
            this.btnSaveFile.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnSaveFile.Location = new System.Drawing.Point(125, 136);
            this.btnSaveFile.Name = "btnSaveFile";
            this.btnSaveFile.Size = new System.Drawing.Size(75, 23);
            this.btnSaveFile.TabIndex = 3;
            this.btnSaveFile.Text = "数据保存";
            this.btnSaveFile.UseVisualStyleBackColor = false;
            this.btnSaveFile.Click += new System.EventHandler(this.btnSaveFile_Click);
            // 
            // btnClearReceived
            // 
            this.btnClearReceived.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClearReceived.Location = new System.Drawing.Point(18, 136);
            this.btnClearReceived.Name = "btnClearReceived";
            this.btnClearReceived.Size = new System.Drawing.Size(75, 23);
            this.btnClearReceived.TabIndex = 2;
            this.btnClearReceived.Text = "清空内容";
            this.btnClearReceived.UseVisualStyleBackColor = false;
            this.btnClearReceived.Click += new System.EventHandler(this.btnClearReceived_Click);
            // 
            // cb16Display
            // 
            this.cb16Display.AutoSize = true;
            this.cb16Display.Location = new System.Drawing.Point(18, 105);
            this.cb16Display.Name = "cb16Display";
            this.cb16Display.Size = new System.Drawing.Size(96, 16);
            this.cb16Display.TabIndex = 1;
            this.cb16Display.Text = "按16进制显示";
            this.cb16Display.UseVisualStyleBackColor = true;
            this.cb16Display.CheckedChanged += new System.EventHandler(this.cb16Display_CheckedChanged_1);
            // 
            // tbReceivedData
            // 
            this.tbReceivedData.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tbReceivedData.Location = new System.Drawing.Point(18, 23);
            this.tbReceivedData.Multiline = true;
            this.tbReceivedData.Name = "tbReceivedData";
            this.tbReceivedData.ReadOnly = true;
            this.tbReceivedData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbReceivedData.Size = new System.Drawing.Size(182, 76);
            this.tbReceivedData.TabIndex = 0;
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox4.Controls.Add(this.btnReadFile);
            this.groupBox4.Controls.Add(this.cb16Send);
            this.groupBox4.Controls.Add(this.btnSend);
            this.groupBox4.Controls.Add(this.btnClearSend);
            this.groupBox4.Controls.Add(this.label9);
            this.groupBox4.Controls.Add(this.tbSpaceTime);
            this.groupBox4.Controls.Add(this.cbAutomaticSend);
            this.groupBox4.Controls.Add(this.tbSendData);
            this.groupBox4.Location = new System.Drawing.Point(0, 391);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(228, 231);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "数据发送区";
            // 
            // btnReadFile
            // 
            this.btnReadFile.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnReadFile.Location = new System.Drawing.Point(18, 154);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(75, 23);
            this.btnReadFile.TabIndex = 7;
            this.btnReadFile.Text = "读入文件";
            this.btnReadFile.UseVisualStyleBackColor = false;
            this.btnReadFile.Click += new System.EventHandler(this.btnReadFile_Click);
            // 
            // cb16Send
            // 
            this.cb16Send.AutoSize = true;
            this.cb16Send.Location = new System.Drawing.Point(18, 125);
            this.cb16Send.Name = "cb16Send";
            this.cb16Send.Size = new System.Drawing.Size(96, 16);
            this.cb16Send.TabIndex = 6;
            this.cb16Send.Text = "按16进制发送";
            this.cb16Send.UseVisualStyleBackColor = true;
            this.cb16Send.CheckedChanged += new System.EventHandler(this.cb16Send_CheckedChanged);
            // 
            // btnSend
            // 
            this.btnSend.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnSend.Location = new System.Drawing.Point(102, 183);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 5;
            this.btnSend.Text = "发送";
            this.btnSend.UseVisualStyleBackColor = false;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // btnClearSend
            // 
            this.btnClearSend.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClearSend.Location = new System.Drawing.Point(18, 183);
            this.btnClearSend.Name = "btnClearSend";
            this.btnClearSend.Size = new System.Drawing.Size(75, 23);
            this.btnClearSend.TabIndex = 4;
            this.btnClearSend.Text = "清空内容";
            this.btnClearSend.UseVisualStyleBackColor = false;
            this.btnClearSend.Click += new System.EventHandler(this.btnClearSend_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(183, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(17, 12);
            this.label9.TabIndex = 3;
            this.label9.Text = "ms";
            // 
            // tbSpaceTime
            // 
            this.tbSpaceTime.Location = new System.Drawing.Point(137, 101);
            this.tbSpaceTime.Name = "tbSpaceTime";
            this.tbSpaceTime.Size = new System.Drawing.Size(40, 21);
            this.tbSpaceTime.TabIndex = 2;
            this.tbSpaceTime.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSpaceTime_KeyPress);
            // 
            // cbAutomaticSend
            // 
            this.cbAutomaticSend.AutoSize = true;
            this.cbAutomaticSend.Location = new System.Drawing.Point(18, 103);
            this.cbAutomaticSend.Name = "cbAutomaticSend";
            this.cbAutomaticSend.Size = new System.Drawing.Size(108, 16);
            this.cbAutomaticSend.TabIndex = 1;
            this.cbAutomaticSend.Text = "自动发送：间隔";
            this.cbAutomaticSend.UseVisualStyleBackColor = true;
            this.cbAutomaticSend.CheckedChanged += new System.EventHandler(this.cbAutomaticSend_CheckedChanged);
            // 
            // tbSendData
            // 
            this.tbSendData.Location = new System.Drawing.Point(18, 16);
            this.tbSendData.Multiline = true;
            this.tbSendData.Name = "tbSendData";
            this.tbSendData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbSendData.Size = new System.Drawing.Size(182, 78);
            this.tbSendData.TabIndex = 0;
            this.tbSendData.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbSendData_KeyPress);
            this.tbSendData.KeyUp += new System.Windows.Forms.KeyEventHandler(this.tbSendData_KeyUp);
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox8.Controls.Add(this.label47);
            this.groupBox8.Controls.Add(this.label48);
            this.groupBox8.Controls.Add(this.zitaiCOMPort);
            this.groupBox8.Controls.Add(this.zitaiSendCount);
            this.groupBox8.Controls.Add(this.zitaiSendData);
            this.groupBox8.Controls.Add(this.label49);
            this.groupBox8.Controls.Add(this.zitaiClearData);
            this.groupBox8.Location = new System.Drawing.Point(236, 451);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(326, 174);
            this.groupBox8.TabIndex = 57;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "波形显示";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(221, 63);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(89, 12);
            this.label47.TabIndex = 14;
            this.label47.Text = "波形显示串口号";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Location = new System.Drawing.Point(6, 22);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(113, 12);
            this.label48.TabIndex = 15;
            this.label48.Text = "波形显示数据发送区";
            // 
            // zitaiCOMPort
            // 
            this.zitaiCOMPort.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.zitaiCOMPort.FormattingEnabled = true;
            this.zitaiCOMPort.Location = new System.Drawing.Point(233, 91);
            this.zitaiCOMPort.Name = "zitaiCOMPort";
            this.zitaiCOMPort.Size = new System.Drawing.Size(59, 20);
            this.zitaiCOMPort.TabIndex = 14;
            // 
            // zitaiSendCount
            // 
            this.zitaiSendCount.BackColor = System.Drawing.Color.White;
            this.zitaiSendCount.Location = new System.Drawing.Point(152, 126);
            this.zitaiSendCount.Name = "zitaiSendCount";
            this.zitaiSendCount.Size = new System.Drawing.Size(52, 21);
            this.zitaiSendCount.TabIndex = 14;
            // 
            // zitaiSendData
            // 
            this.zitaiSendData.Location = new System.Drawing.Point(6, 37);
            this.zitaiSendData.Multiline = true;
            this.zitaiSendData.Name = "zitaiSendData";
            this.zitaiSendData.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.zitaiSendData.Size = new System.Drawing.Size(198, 78);
            this.zitaiSendData.TabIndex = 8;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(87, 131);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(65, 12);
            this.label49.TabIndex = 14;
            this.label49.Text = "发送(byte)";
            // 
            // zitaiClearData
            // 
            this.zitaiClearData.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.zitaiClearData.Location = new System.Drawing.Point(6, 126);
            this.zitaiClearData.Name = "zitaiClearData";
            this.zitaiClearData.Size = new System.Drawing.Size(75, 23);
            this.zitaiClearData.TabIndex = 8;
            this.zitaiClearData.Text = "清空内容";
            this.zitaiClearData.UseVisualStyleBackColor = false;
            this.zitaiClearData.Click += new System.EventHandler(this.zitaiClearData_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3});
            this.statusStrip1.Location = new System.Drawing.Point(0, 639);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1104, 22);
            this.statusStrip1.TabIndex = 4;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel1.Text = "toolStripStatusLabel1";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(827, 17);
            this.toolStripStatusLabel2.Spring = true;
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(131, 17);
            this.toolStripStatusLabel3.Text = "toolStripStatusLabel3";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox5.Controls.Add(this.label44);
            this.groupBox5.Controls.Add(this.label43);
            this.groupBox5.Controls.Add(this.label56);
            this.groupBox5.Controls.Add(this.hangxiang);
            this.groupBox5.Controls.Add(this.jingjie_d);
            this.groupBox5.Controls.Add(this.label55);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.qian_distance);
            this.groupBox5.Controls.Add(this.weidu);
            this.groupBox5.Controls.Add(this.jingdu);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label2);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label24);
            this.groupBox5.Controls.Add(this.label23);
            this.groupBox5.Controls.Add(this.label22);
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.label21);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.temperature);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.angle3);
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.angle2);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.angle1);
            this.groupBox5.Controls.Add(this.acceleration3);
            this.groupBox5.Controls.Add(this.acceleration2);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.acceleration1);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.right_distance);
            this.groupBox5.Controls.Add(this.left_distance);
            this.groupBox5.Location = new System.Drawing.Point(236, 12);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(328, 232);
            this.groupBox5.TabIndex = 5;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "数据显示区";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label44.Location = new System.Drawing.Point(288, 176);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(16, 16);
            this.label44.TabIndex = 52;
            this.label44.Text = "m";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label43.Location = new System.Drawing.Point(291, 205);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(24, 16);
            this.label43.TabIndex = 51;
            this.label43.Text = "°";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label56.Location = new System.Drawing.Point(288, 27);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(16, 16);
            this.label56.TabIndex = 53;
            this.label56.Text = "m";
            // 
            // hangxiang
            // 
            this.hangxiang.Location = new System.Drawing.Point(219, 200);
            this.hangxiang.Name = "hangxiang";
            this.hangxiang.Size = new System.Drawing.Size(66, 21);
            this.hangxiang.TabIndex = 50;
            // 
            // jingjie_d
            // 
            this.jingjie_d.Location = new System.Drawing.Point(244, 23);
            this.jingjie_d.Name = "jingjie_d";
            this.jingjie_d.Size = new System.Drawing.Size(40, 21);
            this.jingjie_d.TabIndex = 57;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Location = new System.Drawing.Point(157, 25);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(79, 14);
            this.label55.TabIndex = 62;
            this.label55.Text = "警戒触发距离";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(184, 203);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 49;
            this.label5.Text = "航向";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Location = new System.Drawing.Point(157, 176);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 14);
            this.label4.TabIndex = 48;
            this.label4.Text = "前端距离";
            // 
            // qian_distance
            // 
            this.qian_distance.Location = new System.Drawing.Point(219, 173);
            this.qian_distance.Name = "qian_distance";
            this.qian_distance.Size = new System.Drawing.Size(66, 21);
            this.qian_distance.TabIndex = 47;
            // 
            // weidu
            // 
            this.weidu.Location = new System.Drawing.Point(64, 200);
            this.weidu.Name = "weidu";
            this.weidu.Size = new System.Drawing.Size(66, 21);
            this.weidu.TabIndex = 46;
            // 
            // jingdu
            // 
            this.jingdu.Location = new System.Drawing.Point(64, 166);
            this.jingdu.Name = "jingdu";
            this.jingdu.Size = new System.Drawing.Size(66, 21);
            this.jingdu.TabIndex = 45;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 44;
            this.label3.Text = "纬度";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 176);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 12);
            this.label2.TabIndex = 43;
            this.label2.Text = "经度";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label28.Location = new System.Drawing.Point(136, 142);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 16);
            this.label28.TabIndex = 42;
            this.label28.Text = "°/s²";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label27.Location = new System.Drawing.Point(136, 111);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(48, 16);
            this.label27.TabIndex = 41;
            this.label27.Text = "°/s²";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label26.Location = new System.Drawing.Point(136, 84);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(48, 16);
            this.label26.TabIndex = 40;
            this.label26.Text = "°/s²";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label25.Location = new System.Drawing.Point(288, 142);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(40, 16);
            this.label25.TabIndex = 39;
            this.label25.Text = "m/s²";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label24.Location = new System.Drawing.Point(288, 111);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(40, 16);
            this.label24.TabIndex = 38;
            this.label24.Text = "m/s²";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label23.Location = new System.Drawing.Point(288, 85);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 16);
            this.label23.TabIndex = 37;
            this.label23.Text = "m/s²";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label22.Location = new System.Drawing.Point(137, 29);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 36;
            this.label22.Text = "℃";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label20.Location = new System.Drawing.Point(136, 49);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(24, 16);
            this.label20.TabIndex = 35;
            this.label20.Text = "cm";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label21.Location = new System.Drawing.Point(288, 49);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(24, 16);
            this.label21.TabIndex = 34;
            this.label21.Text = "cm";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(30, 23);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(29, 12);
            this.label18.TabIndex = 30;
            this.label18.Text = "温度";
            // 
            // temperature
            // 
            this.temperature.Location = new System.Drawing.Point(64, 22);
            this.temperature.Name = "temperature";
            this.temperature.Size = new System.Drawing.Size(66, 21);
            this.temperature.TabIndex = 29;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(0, 142);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 12);
            this.label17.TabIndex = 28;
            this.label17.Text = "角加速度3";
            // 
            // angle3
            // 
            this.angle3.Location = new System.Drawing.Point(64, 137);
            this.angle3.Name = "angle3";
            this.angle3.Size = new System.Drawing.Size(66, 21);
            this.angle3.TabIndex = 27;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(0, 114);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(59, 12);
            this.label16.TabIndex = 26;
            this.label16.Text = "角加速度2";
            // 
            // angle2
            // 
            this.angle2.Location = new System.Drawing.Point(64, 107);
            this.angle2.Name = "angle2";
            this.angle2.Size = new System.Drawing.Size(66, 21);
            this.angle2.TabIndex = 25;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(0, 84);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 12);
            this.label15.TabIndex = 24;
            this.label15.Text = "角加速度1";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(170, 142);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 23;
            this.label14.Text = "加速度3";
            // 
            // angle1
            // 
            this.angle1.Location = new System.Drawing.Point(64, 80);
            this.angle1.Name = "angle1";
            this.angle1.Size = new System.Drawing.Size(66, 21);
            this.angle1.TabIndex = 22;
            // 
            // acceleration3
            // 
            this.acceleration3.Location = new System.Drawing.Point(219, 139);
            this.acceleration3.Name = "acceleration3";
            this.acceleration3.Size = new System.Drawing.Size(66, 21);
            this.acceleration3.TabIndex = 21;
            // 
            // acceleration2
            // 
            this.acceleration2.Location = new System.Drawing.Point(219, 111);
            this.acceleration2.Name = "acceleration2";
            this.acceleration2.Size = new System.Drawing.Size(66, 21);
            this.acceleration2.TabIndex = 20;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(171, 114);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 19;
            this.label13.Text = "加速度2";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(171, 85);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 12);
            this.label12.TabIndex = 18;
            this.label12.Text = "加速度1";
            // 
            // acceleration1
            // 
            this.acceleration1.Location = new System.Drawing.Point(219, 82);
            this.acceleration1.Name = "acceleration1";
            this.acceleration1.Size = new System.Drawing.Size(66, 21);
            this.acceleration1.TabIndex = 17;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(171, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(41, 12);
            this.label10.TabIndex = 4;
            this.label10.Text = "右距离";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(19, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 3;
            this.label6.Text = "左距离";
            // 
            // right_distance
            // 
            this.right_distance.Location = new System.Drawing.Point(219, 52);
            this.right_distance.Name = "right_distance";
            this.right_distance.Size = new System.Drawing.Size(66, 21);
            this.right_distance.TabIndex = 1;
            // 
            // left_distance
            // 
            this.left_distance.Location = new System.Drawing.Point(64, 49);
            this.left_distance.Name = "left_distance";
            this.left_distance.Size = new System.Drawing.Size(66, 21);
            this.left_distance.TabIndex = 0;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox6.Controls.Add(this.label57);
            this.groupBox6.Controls.Add(this.duzhiling_jiange);
            this.groupBox6.Controls.Add(this.button2);
            this.groupBox6.Controls.Add(this.button1);
            this.groupBox6.Controls.Add(this.label51);
            this.groupBox6.Controls.Add(this.sd_SpaceTime);
            this.groupBox6.Controls.Add(this.sd_AutomaticSend);
            this.groupBox6.Controls.Add(this.shoudong_ctrl);
            this.groupBox6.Controls.Add(this.label40);
            this.groupBox6.Controls.Add(this.label38);
            this.groupBox6.Controls.Add(this.label37);
            this.groupBox6.Controls.Add(this.label32);
            this.groupBox6.Controls.Add(this.label36);
            this.groupBox6.Controls.Add(this.label35);
            this.groupBox6.Controls.Add(this.label34);
            this.groupBox6.Controls.Add(this.label33);
            this.groupBox6.Controls.Add(this.label31);
            this.groupBox6.Controls.Add(this.right_dangwei);
            this.groupBox6.Controls.Add(this.left_dangwei);
            this.groupBox6.Controls.Add(this.label30);
            this.groupBox6.Controls.Add(this.label29);
            this.groupBox6.Location = new System.Drawing.Point(234, 250);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(328, 199);
            this.groupBox6.TabIndex = 6;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "控制区";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(277, 175);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(17, 12);
            this.label57.TabIndex = 70;
            this.label57.Text = "ms";
            // 
            // duzhiling_jiange
            // 
            this.duzhiling_jiange.Location = new System.Drawing.Point(234, 170);
            this.duzhiling_jiange.Name = "duzhiling_jiange";
            this.duzhiling_jiange.Size = new System.Drawing.Size(40, 21);
            this.duzhiling_jiange.TabIndex = 69;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button2.Location = new System.Drawing.Point(235, 141);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(87, 23);
            this.button2.TabIndex = 8;
            this.button2.Text = "读入历史动作";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.button1.Location = new System.Drawing.Point(154, 141);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "保存动作";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(157, 177);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(17, 12);
            this.label51.TabIndex = 8;
            this.label51.Text = "ms";
            // 
            // sd_SpaceTime
            // 
            this.sd_SpaceTime.Location = new System.Drawing.Point(114, 172);
            this.sd_SpaceTime.Name = "sd_SpaceTime";
            this.sd_SpaceTime.Size = new System.Drawing.Size(40, 21);
            this.sd_SpaceTime.TabIndex = 8;
            // 
            // sd_AutomaticSend
            // 
            this.sd_AutomaticSend.AutoSize = true;
            this.sd_AutomaticSend.Location = new System.Drawing.Point(10, 176);
            this.sd_AutomaticSend.Name = "sd_AutomaticSend";
            this.sd_AutomaticSend.Size = new System.Drawing.Size(108, 16);
            this.sd_AutomaticSend.TabIndex = 8;
            this.sd_AutomaticSend.Text = "自动发送：间隔";
            this.sd_AutomaticSend.UseVisualStyleBackColor = true;
            this.sd_AutomaticSend.CheckedChanged += new System.EventHandler(this.sd_AutomaticSend_CheckedChanged);
            // 
            // shoudong_ctrl
            // 
            this.shoudong_ctrl.AutoSize = true;
            this.shoudong_ctrl.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.shoudong_ctrl.Location = new System.Drawing.Point(30, 147);
            this.shoudong_ctrl.Name = "shoudong_ctrl";
            this.shoudong_ctrl.Size = new System.Drawing.Size(91, 20);
            this.shoudong_ctrl.TabIndex = 8;
            this.shoudong_ctrl.Text = "手动控制";
            this.shoudong_ctrl.UseVisualStyleBackColor = true;
            this.shoudong_ctrl.CheckedChanged += new System.EventHandler(this.shoudong_ctrl_CheckedChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label40.Location = new System.Drawing.Point(133, 90);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(44, 16);
            this.label40.TabIndex = 54;
            this.label40.Text = "S后退";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label38.Location = new System.Drawing.Point(7, 66);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(84, 14);
            this.label38.TabIndex = 53;
            this.label38.Text = "I左电机加档";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label37.Location = new System.Drawing.Point(113, 119);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(72, 16);
            this.label37.TabIndex = 52;
            this.label37.Text = "J紧急暂停";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label32.Location = new System.Drawing.Point(7, 113);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(84, 14);
            this.label32.TabIndex = 47;
            this.label32.Text = "K左电机减档";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label36.Location = new System.Drawing.Point(231, 66);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(84, 14);
            this.label36.TabIndex = 51;
            this.label36.Text = "O右电机加档";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label35.Location = new System.Drawing.Point(133, 67);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(44, 16);
            this.label35.TabIndex = 50;
            this.label35.Text = "W前进";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label34.Location = new System.Drawing.Point(231, 113);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(84, 14);
            this.label34.TabIndex = 49;
            this.label34.Text = "L右电机减档";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label33.Location = new System.Drawing.Point(181, 90);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(44, 16);
            this.label33.TabIndex = 48;
            this.label33.Text = "D右转";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label31.Location = new System.Drawing.Point(79, 90);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(44, 16);
            this.label31.TabIndex = 43;
            this.label31.Text = "A左转";
            // 
            // right_dangwei
            // 
            this.right_dangwei.Location = new System.Drawing.Point(172, 36);
            this.right_dangwei.Name = "right_dangwei";
            this.right_dangwei.Size = new System.Drawing.Size(66, 21);
            this.right_dangwei.TabIndex = 46;
            // 
            // left_dangwei
            // 
            this.left_dangwei.Location = new System.Drawing.Point(67, 36);
            this.left_dangwei.Name = "left_dangwei";
            this.left_dangwei.Size = new System.Drawing.Size(66, 21);
            this.left_dangwei.TabIndex = 43;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(170, 18);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 45;
            this.label30.Text = "右电机档位";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(68, 18);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(65, 12);
            this.label29.TabIndex = 43;
            this.label29.Text = "左电机档位";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(6, 76);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(89, 12);
            this.label52.TabIndex = 16;
            this.label52.Text = "红色障碍物指令";
            // 
            // shipin_ctrl
            // 
            this.shipin_ctrl.AutoSize = true;
            this.shipin_ctrl.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.shipin_ctrl.Location = new System.Drawing.Point(37, 51);
            this.shipin_ctrl.Name = "shipin_ctrl";
            this.shipin_ctrl.Size = new System.Drawing.Size(123, 20);
            this.shipin_ctrl.TabIndex = 57;
            this.shipin_ctrl.Text = "屏蔽视频控制";
            this.shipin_ctrl.UseVisualStyleBackColor = true;
            this.shipin_ctrl.CheckedChanged += new System.EventHandler(this.shipin_ctrl_CheckedChanged);
            // 
            // zhiling_jieshou_count
            // 
            this.zhiling_jieshou_count.BackColor = System.Drawing.Color.White;
            this.zhiling_jieshou_count.Location = new System.Drawing.Point(269, 48);
            this.zhiling_jieshou_count.Name = "zhiling_jieshou_count";
            this.zhiling_jieshou_count.Size = new System.Drawing.Size(49, 21);
            this.zhiling_jieshou_count.TabIndex = 58;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(198, 51);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(65, 12);
            this.label50.TabIndex = 59;
            this.label50.Text = "接收(byte)";
            // 
            // zhiling_clear
            // 
            this.zhiling_clear.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.zhiling_clear.Location = new System.Drawing.Point(196, 22);
            this.zhiling_clear.Name = "zhiling_clear";
            this.zhiling_clear.Size = new System.Drawing.Size(67, 23);
            this.zhiling_clear.TabIndex = 60;
            this.zhiling_clear.Text = "清空内容";
            this.zhiling_clear.UseVisualStyleBackColor = false;
            this.zhiling_clear.Click += new System.EventHandler(this.zhiling_clear_Click);
            // 
            // hong_zhiling
            // 
            this.hong_zhiling.Location = new System.Drawing.Point(6, 95);
            this.hong_zhiling.Multiline = true;
            this.hong_zhiling.Name = "hong_zhiling";
            this.hong_zhiling.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.hong_zhiling.Size = new System.Drawing.Size(114, 76);
            this.hong_zhiling.TabIndex = 8;
            // 
            // zhiling_list
            // 
            this.zhiling_list.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.zhiling_list.Location = new System.Drawing.Point(8, 176);
            this.zhiling_list.Name = "zhiling_list";
            this.zhiling_list.Size = new System.Drawing.Size(87, 23);
            this.zhiling_list.TabIndex = 14;
            this.zhiling_list.Text = "键入绕障指令";
            this.zhiling_list.UseVisualStyleBackColor = false;
            this.zhiling_list.Click += new System.EventHandler(this.zhiling_list_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(6, 30);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(89, 12);
            this.label19.TabIndex = 14;
            this.label19.Text = "程控指令串口号";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox7.Controls.Add(this.videoSourcePlayer);
            this.groupBox7.Controls.Add(this.Photograph);
            this.groupBox7.Controls.Add(this.btnClose);
            this.groupBox7.Controls.Add(this.btnConnect);
            this.groupBox7.Controls.Add(this.label45);
            this.groupBox7.Controls.Add(this.tscbxCameras);
            this.groupBox7.Location = new System.Drawing.Point(577, 12);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(497, 376);
            this.groupBox7.TabIndex = 7;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "摄像头";
            // 
            // videoSourcePlayer
            // 
            this.videoSourcePlayer.Location = new System.Drawing.Point(6, 50);
            this.videoSourcePlayer.Name = "videoSourcePlayer";
            this.videoSourcePlayer.Size = new System.Drawing.Size(485, 323);
            this.videoSourcePlayer.TabIndex = 14;
            this.videoSourcePlayer.Text = "videoSourcePlayer";
            this.videoSourcePlayer.VideoSource = null;
            // 
            // Photograph
            // 
            this.Photograph.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Photograph.Location = new System.Drawing.Point(416, 18);
            this.Photograph.Name = "Photograph";
            this.Photograph.Size = new System.Drawing.Size(75, 23);
            this.Photograph.TabIndex = 13;
            this.Photograph.Text = "截图拍照";
            this.Photograph.UseVisualStyleBackColor = false;
            this.Photograph.Click += new System.EventHandler(this.Photograph_Click_1);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnClose.Location = new System.Drawing.Point(326, 18);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 12;
            this.btnClose.Text = "关闭";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // btnConnect
            // 
            this.btnConnect.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.btnConnect.Location = new System.Drawing.Point(232, 17);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(75, 24);
            this.btnConnect.TabIndex = 11;
            this.btnConnect.Text = "连接";
            this.btnConnect.UseVisualStyleBackColor = false;
            this.btnConnect.Click += new System.EventHandler(this.btnConnect_Click_1);
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(6, 25);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(89, 12);
            this.label45.TabIndex = 10;
            this.label45.Text = "视频输入设备：";
            // 
            // tscbxCameras
            // 
            this.tscbxCameras.FormattingEnabled = true;
            this.tscbxCameras.Location = new System.Drawing.Point(96, 19);
            this.tscbxCameras.Name = "tscbxCameras";
            this.tscbxCameras.Size = new System.Drawing.Size(96, 20);
            this.tscbxCameras.TabIndex = 8;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(942, 405);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 121);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(931, 529);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(161, 14);
            this.label11.TabIndex = 9;
            this.label11.Text = "哈尔滨工业大学（威海）";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.Control;
            this.groupBox1.Controls.Add(this.jianru_xilie);
            this.groupBox1.Controls.Add(this.label42);
            this.groupBox1.Controls.Add(this.xiliezhiling);
            this.groupBox1.Controls.Add(this.label58);
            this.groupBox1.Controls.Add(this.label54);
            this.groupBox1.Controls.Add(this.zhiling_jiange);
            this.groupBox1.Controls.Add(this.label52);
            this.groupBox1.Controls.Add(this.label53);
            this.groupBox1.Controls.Add(this.label50);
            this.groupBox1.Controls.Add(this.zhiling_jieshou_count);
            this.groupBox1.Controls.Add(this.zhiling_clear);
            this.groupBox1.Controls.Add(this.hong_zhiling);
            this.groupBox1.Controls.Add(this.shipin_ctrl);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.zhilingCOMPort);
            this.groupBox1.Controls.Add(this.zhiling_list);
            this.groupBox1.Location = new System.Drawing.Point(577, 397);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(339, 228);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "程控指令";
            // 
            // jianru_xilie
            // 
            this.jianru_xilie.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.jianru_xilie.Location = new System.Drawing.Point(162, 174);
            this.jianru_xilie.Name = "jianru_xilie";
            this.jianru_xilie.Size = new System.Drawing.Size(88, 23);
            this.jianru_xilie.TabIndex = 68;
            this.jianru_xilie.Text = "键入程控指令";
            this.jianru_xilie.UseVisualStyleBackColor = false;
            this.jianru_xilie.Click += new System.EventHandler(this.jianru_xilie_Click);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(160, 80);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(53, 12);
            this.label42.TabIndex = 67;
            this.label42.Text = "程控指令";
            // 
            // xiliezhiling
            // 
            this.xiliezhiling.Location = new System.Drawing.Point(164, 95);
            this.xiliezhiling.Multiline = true;
            this.xiliezhiling.Name = "xiliezhiling";
            this.xiliezhiling.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.xiliezhiling.Size = new System.Drawing.Size(114, 76);
            this.xiliezhiling.TabIndex = 66;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(18, 208);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(113, 12);
            this.label58.TabIndex = 65;
            this.label58.Text = "指令之间用空格分开";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(267, 208);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(17, 12);
            this.label54.TabIndex = 61;
            this.label54.Text = "ms";
            // 
            // zhiling_jiange
            // 
            this.zhiling_jiange.Location = new System.Drawing.Point(221, 201);
            this.zhiling_jiange.Name = "zhiling_jiange";
            this.zhiling_jiange.Size = new System.Drawing.Size(40, 21);
            this.zhiling_jiange.TabIndex = 57;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(162, 208);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(53, 12);
            this.label53.TabIndex = 16;
            this.label53.Text = "指令间隔";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("微软雅黑", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label46.Location = new System.Drawing.Point(958, 551);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(110, 46);
            this.label46.TabIndex = 10;
            this.label46.Text = "HITer";
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label41.Location = new System.Drawing.Point(931, 611);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(147, 14);
            this.label41.TabIndex = 58;
            this.label41.Text = "2019  扬州  智能航行";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ClientSize = new System.Drawing.Size(1104, 661);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label46);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox6);
            this.Name = "Form1";
            this.Text = "智能航行串口助手_hitwh";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion
        private System.Windows.Forms.ComboBox cbxCOMPort;
        private System.Windows.Forms.Button btnOpenCom;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox tbReceivedCount;
        private System.Windows.Forms.TextBox tbSendCount;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnClearCount;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnClearReceived;
        private System.Windows.Forms.CheckBox cb16Display;
        private System.Windows.Forms.TextBox tbReceivedData;
        private System.Windows.Forms.TextBox tbSpaceTime;
        private System.Windows.Forms.CheckBox cbAutomaticSend;
        private System.Windows.Forms.TextBox tbSendData;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.Button btnClearSend;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.CheckBox cb16Send;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnSaveFile;
        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox angle1;
        private System.Windows.Forms.TextBox acceleration3;
        private System.Windows.Forms.TextBox acceleration2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox acceleration1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox right_distance;
        private System.Windows.Forms.TextBox left_distance;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox angle3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox angle2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox temperature;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox right_dangwei;
        private System.Windows.Forms.TextBox left_dangwei;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Button setbutton;
        private System.Windows.Forms.Button freshbutton;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox hangxiang;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox qian_distance;
        private System.Windows.Forms.TextBox weidu;
        private System.Windows.Forms.TextBox jingdu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private AForge.Controls.VideoSourcePlayer videoSourcePlayer;
        private System.Windows.Forms.Button Photograph;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.ComboBox tscbxCameras;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.ComboBox zitaiCOMPort;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox zhilingCOMPort;
        private System.Windows.Forms.ComboBox recCOMPort;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.TextBox zitaiSendData;
        private System.Windows.Forms.Button zitaiClearData;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox zitaiSendCount;
        private System.Windows.Forms.CheckBox shoudong_ctrl;
        private System.Windows.Forms.CheckBox shipin_ctrl;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox zhiling_jieshou_count;
        private System.Windows.Forms.Button zhiling_clear;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox sd_SpaceTime;
        private System.Windows.Forms.CheckBox sd_AutomaticSend;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Button zhiling_list;
        private System.Windows.Forms.TextBox hong_zhiling;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox zhiling_jiange;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox jingjie_d;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button jianru_xilie;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox xiliezhiling;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox duzhiling_jiange;
    }
}

