﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing.Imaging;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Media.Imaging;
using System.IO;
using System.Collections;
using AForge;
using AForge.Controls;
using AForge.Video;
using AForge.Video.DirectShow;
using Size = System.Drawing.Size;

namespace 串口助手sdd
{
    public partial class Form1 : Form
    {
        /// ////////////////////////////////<初始化及刷新代码>////////////////////////////////////
        #region 
        //声明变量
        SerialPort sp_jieshou = new SerialPort();//实例化sp_jieshou这个串口变量,用于接收
        SerialPort sp_fasong = new SerialPort();//实例化sp_fasong这个串口变量,用于发送
        SerialPort sp_zitai = new SerialPort();//实例化sp_zitai，用于发姿态
        SerialPort sp_shexiangtou = new SerialPort();//实例化sp_shexiangtou，用于接收左右指令
        bool isSetProperty = false;//串口属性设置标志位，bool为布尔值、真假
        private FilterInfoCollection videoDevices;
        private VideoCaptureDevice videoSource;       
        string path = AppDomain.CurrentDomain.BaseDirectory + "confing.ini";//声明配置文件路径
        string tbSendDataStr = "";//发送窗口字符串存储
        string tbSendData16 = "";//发送窗口16进制存储
        string zitaiSendData16 = "";
        List<byte> receivedDatas = new List<byte>();//接收数据泛型数组
       
        List<byte> dongzuoDatas = new List<byte>();
        float jingjie_distance;
        //Port Information
        public PortInfo portInfo;
        
      
        //声明接口显示状态，枚举型
        private enum PortState
        {
            打开,
            关闭
        }

      
        public PortInfo PortInfo
        {
            get { return portInfo; }
            set { portInfo = value; }
        }

        //界面参量加载
        public Form1()
        {
            InitializeComponent();
            portInfo = new PortInfo(9600, 8, Parity.None, StopBits.One);           
            saveFileDialog1 = new SaveFileDialog();
            openFileDialog1 = new OpenFileDialog();
            saveFileDialog1.RestoreDirectory = true;
            openFileDialog1.RestoreDirectory = true;
            AutoFindPort();
        }

        //端口显示状态函数
        private void DisplayPortState(PortState portState)//端口处于打开或关闭状态
        {
            string display_Baudrate = portInfo.Baudrate.ToString();
            string display_DataBits = portInfo.DataBits.ToString();
            string STOPBITS;
            string PARITY;

            switch (portInfo.STOPBITS)//  设置停止位
            {
                case StopBits.One: STOPBITS = "1"; break;
                case StopBits.OnePointFive: STOPBITS = "1.5"; break;
                case StopBits.Two: STOPBITS = "2"; break;
                default: STOPBITS = "无"; break;
            }

            switch (portInfo.PARITY)//设置奇偶校验位 
            {
                case Parity.None: PARITY = "无"; break;
                case Parity.Odd: PARITY = "奇校验"; break;
                case Parity.Even: PARITY = "偶校验"; break;
                default: PARITY = "无"; break;
            }
            toolStripStatusLabel1.Text = cbxCOMPort.Text +
                "发送端口 处于" + portState + "状态/ " +
                recCOMPort.Text + "接收端口 处于" + portState + "状态/ " +
                zhilingCOMPort.Text + "摄像头端口 处于" + portState + "状态/ " +
                zitaiCOMPort.Text + "姿态端口 处于" + portState + "状态/ " +
                display_Baudrate + " " + display_DataBits + " " + STOPBITS + " " + PARITY;
        }

        //刷新串口
        public void AutoFindPort()
        {
            #region 加载配置文件
            Hashtable ht = new Hashtable();
            if (File.Exists(path))
            {
                try
                {
                    string myline = "";
                    string[] str = new string[2];
                    using (StreamReader sr = new StreamReader(path))
                    {
                        myline = sr.ReadLine();
                        while (myline != null)
                        {
                            str = myline.Split('=');
                            ht.Add(str[0], str[1]);
                            myline = sr.ReadLine();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("4" + ex.Message.ToString());
                }
            }
            #endregion
            //发送串口
            cbxCOMPort.Items.Clear();//清除当前串口号中的所有串口名称
            cbxCOMPort.Items.AddRange(Methods.ActivePorts());
            //接收串口
            zhilingCOMPort.Items.Clear();//清除当前串口号中的所有串口名称
            zhilingCOMPort.Items.AddRange(Methods.ActivePorts());

            recCOMPort.Items.Clear();//清除当前串口号中的所有串口名称
            recCOMPort.Items.AddRange(Methods.ActivePorts());

            zitaiCOMPort.Items.Clear();//清除当前串口号中的所有串口名称
            zitaiCOMPort.Items.AddRange(Methods.ActivePorts());

            //调用activeports方法，添加有效的串口号，返回mystr数组
            //接收串口
            if (ht.ContainsKey("recCOMPort") && recCOMPort.Items.Contains(ht["recCOMPort"].ToString()))
                recCOMPort.SelectedIndex = recCOMPort.Items.IndexOf(ht["recCOMPort"].ToString());
            else
                recCOMPort.SelectedIndex = 0;
            //发送串口
            if (ht.ContainsKey("cbxCOMPort") && cbxCOMPort.Items.Contains(ht["cbxCOMPort"].ToString()))
                cbxCOMPort.SelectedIndex = cbxCOMPort.Items.IndexOf(ht["cbxCOMPort"].ToString());
            else
                cbxCOMPort.SelectedIndex = 0;
            //指令串口
            if (ht.ContainsKey("zhilingCOMPort") && zhilingCOMPort.Items.Contains(ht["zhilingCOMPort"].ToString()))
                zhilingCOMPort.SelectedIndex = zhilingCOMPort.Items.IndexOf(ht["zhilingCOMPort"].ToString());
            else
                zhilingCOMPort.SelectedIndex = 0;
            //姿态串口
            if (ht.ContainsKey("zitaiCOMPort") && zitaiCOMPort.Items.Contains(ht["zitaiCOMPort"].ToString()))
                zitaiCOMPort.SelectedIndex = zitaiCOMPort.Items.IndexOf(ht["zitaiCOMPort"].ToString());
            else
                zitaiCOMPort.SelectedIndex = 0;

            cbxCOMPort.DropDownStyle = ComboBoxStyle.DropDownList;
            recCOMPort.DropDownStyle = ComboBoxStyle.DropDownList;
            zhilingCOMPort.DropDownStyle = ComboBoxStyle.DropDownList;
            zitaiCOMPort.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        //刷新按键
        private void freshbutton_Click(object sender, EventArgs e)
        {
            AutoFindPort();
        }

        //软件启动时加载事件
        private void Form1_Load(object sender, EventArgs e)
        {

            #region 加载配置文件
            Hashtable ht = new Hashtable();
            if (File.Exists(path))
            {
                try
                {
                    string myline = "";
                    string[] str = new string[2];
                    using (StreamReader sr = new StreamReader(path))
                    {
                        myline = sr.ReadLine();
                        while (myline != null)
                        {
                            str = myline.Split('=');
                            ht.Add(str[0], str[1]);
                            myline = sr.ReadLine();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("5" + ex.Message.ToString());
                }
            }
            #endregion

            #region 设置窗口为固定大小
            this.MaximumSize = this.Size;
            this.MinimumSize = this.Size;
            this.MaximizeBox = true;
            #endregion

            #region 初始化计数器
            tbSendCount.Text = "0";
            tbSendCount.ReadOnly = true;
            tbReceivedCount.Text = "0";
            tbReceivedCount.ReadOnly = true;
            zitaiSendCount.Text = "0";
            zitaiSendCount.ReadOnly = true;
            zhiling_jieshou_count.Text = "0";
            zhiling_jieshou_count.ReadOnly = true;
            #endregion

            #region 初始化当前时间
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
            #endregion

            #region 初始化串口状态
            toolStripStatusLabel1.ForeColor = Color.Blue;


            #endregion

            #region 初始化间隔时间
            if (ht.ContainsKey("tbspaceTime"))
                tbSpaceTime.Text = ht["tbspaceTime"].ToString();
            else
                tbSpaceTime.Text = "1000";

            if (ht.ContainsKey("zhiling_jiange"))
                zhiling_jiange.Text = ht["zhiling_jiange"].ToString();
            else
                zhiling_jiange.Text = "1000";

            if (ht.ContainsKey("sd_SpaceTime"))
                sd_SpaceTime.Text = ht["sd_SpaceTime"].ToString();
            else
                sd_SpaceTime.Text = "1000";
            #endregion

            #region 初始化按16进制显示状态
            if (ht.ContainsKey("cb16Display") && ht["cb16Display"].ToString() == "True")
                cb16Display.Checked = true;
            else
                cb16Display.Checked = false;
            #endregion

            #region 初始化按16进制发送状态
            if (ht.ContainsKey("cb16Send") && ht["cb16Send"].ToString() == "True")
                cb16Send.Checked = true;
            else
                cb16Send.Checked = false;
            #endregion

            #region 初始化船机发送区文本
            if (ht.ContainsKey("tbSendData16") && ht.ContainsKey("tbSendDataStr"))
            {
                tbSendData16 = ht["tbSendData16"].ToString();
                tbSendDataStr = ht["tbSendDataStr"].ToString();
                if (cb16Send.Checked)
                    tbSendData.Text = ht["tbSendData16"].ToString();
                else
                    tbSendData.Text = ht["tbSendDataStr"].ToString();
            }
            #endregion

            #region 初始化姿态发送区文本
            if (ht.ContainsKey("zitaiSendData16"))
            {
                zitaiSendData16 = ht["zitaiSendData16"].ToString();
                zitaiSendData.Text = ht["zitaiSendData16"].ToString();
            }
            #endregion

            #region 枚举所有视频输入设备
            try
            {
                // 枚举所有视频输入设备
                videoDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);

                if (videoDevices.Count == 0)
                    throw new ApplicationException();

                foreach (FilterInfo device in videoDevices)
                {
                    tscbxCameras.Items.Add(device.Name);
                }

                tscbxCameras.SelectedIndex = 0;

            }
            catch (ApplicationException)
            {
                tscbxCameras.Items.Add("No local capture devices");
                videoDevices = null;
            }
            #endregion
            cb16Send.Checked = true;
            cb16Display.Checked = true;

            left_dangwei.Text = (0).ToString();
            right_dangwei.Text = (0).ToString();

            tbSendData.Focus();
            zitaiSendData.Focus();

            shipin_ctrl.Checked = true;
            jingjie_d.Text = "3";
            duzhiling_jiange.Text  = "1000";

            hong_zhiling.Text = "05 05 50 50 50 50 50 50 50 50 44 44 44";
            Hong_zhiling = Methods._16strToHex(hong_zhiling.Text);

        }

        #endregion

        /// ////////////////////////////////<摄像区代码>//////////////////////////////////////////
        #region 

        //连接摄像头
        private void btnConnect_Click_1(object sender, EventArgs e)
        {
            CameraConn();
        }

        //点击是否靠视频控制
        private void shipin_ctrl_CheckedChanged(object sender, EventArgs e)
        {
            if (!shipin_ctrl.Checked)
            {
                sp_shexiangtou.Open();
            }
            else
            {
                sp_shexiangtou.Close();
            }
        }

       

        //摄像头连接函数
        private void CameraConn()
        {
            VideoCaptureDevice videoSource = new VideoCaptureDevice(videoDevices[tscbxCameras.SelectedIndex].MonikerString);
            videoSource.DesiredFrameSize = new System.Drawing.Size(320, 240);
            videoSource.DesiredFrameRate = 1;

            videoSourcePlayer.VideoSource = videoSource;
            videoSourcePlayer.Start();
        }

        //关闭摄像头
        private void btnClose_Click(object sender, EventArgs e)
        {
            videoSourcePlayer.SignalToStop();
            videoSourcePlayer.WaitForStop();
        }

        //主窗体关闭
       private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            btnClose_Click(null, null);
        }
        
        //视频拍照
        private void Photograph_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (videoSourcePlayer.IsRunning)
                {
                    BitmapSource bitmapSource = System.Windows.Interop.Imaging.CreateBitmapSourceFromHBitmap(
                                    videoSourcePlayer.GetCurrentVideoFrame().GetHbitmap(),
                                    IntPtr.Zero,
                                     Int32Rect.Empty,
                                    BitmapSizeOptions.FromEmptyOptions());
                    PngBitmapEncoder pE = new PngBitmapEncoder();
                    pE.Frames.Add(BitmapFrame.Create(bitmapSource));
                    string picName = GetImagePath() + "\\" + "jieping" + ".jpg";
                    if (File.Exists(picName))
                    {
                        File.Delete(picName);
                    }
                    using (Stream stream = File.Create(picName))
                    {
                        pE.Save(stream);
                    }
                    //拍照完成后关摄像头并刷新同时关窗体
                    if (videoSourcePlayer != null && videoSourcePlayer.IsRunning)
                    {
                        videoSourcePlayer.SignalToStop();
                        videoSourcePlayer.WaitForStop();
                    }

                    this.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("摄像头异常：" + ex.Message);
            }
        }

        private string GetImagePath()
        {
            string personImgPath = Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory)
                         + Path.DirectorySeparatorChar.ToString() + "PersonImg";
            if (!Directory.Exists(personImgPath))
            {
                Directory.CreateDirectory(personImgPath);
            }

            return personImgPath;
        }

        #endregion

        /// ////////////////////////////////<收发代码>///////////////////////////////////////////
        #region 
        int j = 0;
        //接收摄像头数据，发送控制指令
        private void sp_shexiangtou_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            byte[] ReceivedData_shexiangtou = new byte[1];//创建接收字节数组                 
            //如果前端距离较大，就通过摄像头来控制
            if (jingjie_distance >= Convert.ToInt32(jingjie_d.Text)||(jingjie_distance<0))
            {
                if (sp_fasong.IsOpen)
                {
                    sp_shexiangtou.Read(ReceivedData_shexiangtou, 0, ReceivedData_shexiangtou.Length);//从缓冲区读取所接收到的数据，并放在指定的偏移量处
                    receivedDatas.AddRange(ReceivedData_shexiangtou);//把收到的数据加到尾部,receivedDatas为总的缓存数据，所有接收数据都存储在其中，便于转为文档或清除                  
                    sp_fasong.Write(ReceivedData_shexiangtou, 0, ReceivedData_shexiangtou.Length);
                    zhiling_jieshou_count.Text = (Convert.ToInt32(zhiling_jieshou_count.Text) + ReceivedData_shexiangtou.Length).ToString();//收数记录
                    sp_shexiangtou.DiscardInBuffer();//丢弃接收缓冲区数据
                }
                else
                {
                    MessageBox.Show("串口未打开!", "错误提示");
                    return;
                }
            }//否则就执行流程化指令
            else
            {
                //如果距离过近，就关掉摄像头指令，把zl2 .Zhiling按一定间隔发给船体              
                shipin_ctrl.Checked = true;
        
                if (sp_fasong.IsOpen)
                {                  
                    do  //不要指令用满30个，保持有多余的0空出来作为停止标志
                    {
                        sp_fasong.Write(Hong_zhiling , j++, 1);
                        Delay(Convert.ToInt32(zhiling_jiange.Text) / 1000);//延时对应时间
                    }
                    while (j < Hong_zhiling.Length);
                    j = 0;
                    shipin_ctrl.Checked = false;
                    jingjie_distance = 100;
                    qian_distance.Text = jingjie_distance.ToString();
                    byte[] xiayigeqiu=new byte [1];
                    xiayigeqiu[0] = 0xff;
                    sp_shexiangtou.Write(xiayigeqiu , 0, 1);
                }
                else
                {
                    MessageBox.Show("串口未打开!", "错误提示");
                    return;
                }
            }

        }
        //延迟函数
        public static bool Delay(int delayTime)
        {
            DateTime now = DateTime.Now;
            int s;
            do
            {
                TimeSpan spand = DateTime.Now - now;
                s = spand.Seconds;
                Application.DoEvents();
            }
            while (s < delayTime);
            return true;
        }

        //接收船机串口数据
        private void sp_jieshou_DataReceived(object sender, SerialDataReceivedEventArgs p)
        {

            int byteNumber = sp_jieshou.BytesToRead;
            System.Threading.Thread.Sleep(20);
            //延时等待数据接收完毕。
            while ((byteNumber < sp_jieshou.BytesToRead) && (sp_jieshou.BytesToRead < 100))
            {
                byteNumber = sp_jieshou.BytesToRead;
                System.Threading.Thread.Sleep(20);
            }

            byte[] ReceivedData_jieshou = new byte[sp_jieshou.BytesToRead];//创建接收字节数组         

            sp_jieshou.Read(ReceivedData_jieshou, 0, ReceivedData_jieshou.Length);//从缓冲区读取所接收到的数据，并放在指定的偏移量处

            receivedDatas.AddRange(ReceivedData_jieshou);//把收到的数据加到尾部,receivedDatas为总的缓存数据，所有接收数据都存储在其中，便于转为文档或清除

            byte[] ReceivedData_hangxiang = new byte[4];//航向

            byte[] ReceivedData_qianduan = new byte[4];//前向距离

            byte[] ReceivedData_wendu = new byte[4];//温度

            byte[] ReceivedData_jingdu = new byte[4];//用于提取经度信息的临时数组

            byte[] ReceivedData_weidu = new byte[4];//用于提取纬度信息的临时数组            

            if (ReceivedData_jieshou.Length == 34)
            {
                left_distance.Text = ReceivedData_jieshou[0].ToString();//将字节数组0提取左距离
                right_distance.Text = ReceivedData_jieshou[1].ToString();//将字节数组1提取右距离

                ReceivedData_hangxiang[0] = ReceivedData_jieshou[2];//提取航向数据
                ReceivedData_hangxiang[1] = ReceivedData_jieshou[3];
                ReceivedData_hangxiang[2] = ReceivedData_jieshou[4];
                ReceivedData_hangxiang[3] = ReceivedData_jieshou[5];
                hangxiang.Text = Convert.ToString(BitConverter.ToSingle(ReceivedData_hangxiang, 0));

                ReceivedData_qianduan[0] = ReceivedData_jieshou[6];//提取前段距离数据
                ReceivedData_qianduan[1] = ReceivedData_jieshou[7];
                ReceivedData_qianduan[2] = ReceivedData_jieshou[8];
                ReceivedData_qianduan[3] = ReceivedData_jieshou[9];
                qian_distance.Text = Convert.ToString(BitConverter.ToSingle(ReceivedData_qianduan, 0));
                jingjie_distance = BitConverter.ToSingle(ReceivedData_qianduan, 0);

                ReceivedData_wendu[0] = ReceivedData_jieshou[10];//提取温度
                ReceivedData_wendu[1] = ReceivedData_jieshou[11];
                ReceivedData_wendu[2] = ReceivedData_jieshou[12];
                ReceivedData_wendu[3] = ReceivedData_jieshou[13];
                temperature.Text = Convert.ToString(BitConverter.ToSingle(ReceivedData_wendu, 0));

                ReceivedData_jingdu[0] = ReceivedData_jieshou[14];//提取经度数据，暂存于ReceivedData_jingdu
                ReceivedData_jingdu[1] = ReceivedData_jieshou[15];
                ReceivedData_jingdu[2] = ReceivedData_jieshou[16];
                ReceivedData_jingdu[3] = ReceivedData_jieshou[17];
                jingdu.Text = Convert.ToString(BitConverter.ToSingle(ReceivedData_jingdu, 0)); //将字节数组转化为浮点数  

                ReceivedData_weidu[0] = ReceivedData_jieshou[18];//提取纬度数据，暂存于ReceivedData_weidu
                ReceivedData_weidu[1] = ReceivedData_jieshou[19];
                ReceivedData_weidu[2] = ReceivedData_jieshou[20];
                ReceivedData_weidu[3] = ReceivedData_jieshou[21];
                weidu.Text = Convert.ToString(BitConverter.ToSingle(ReceivedData_weidu, 0)); //将字节数组转化为浮点数  

                acceleration1.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, true, 22, 23));    //字节数组12-17提取三轴加速度
                acceleration2.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, true, 24, 25));   //
                acceleration3.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, true, 26, 27));   //

                angle1.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, false, 28, 29));      //字节数组18-23提取三个角加速度
                angle2.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, false, 30, 31));      //                
                angle3.Text = Convert.ToString(Methods.byteTo_acc_ang(ReceivedData_jieshou, false, 32, 33));     //                        

                //收到姿态信息马上发给姿态发送区
                DataSend_zitai(ReceivedData_jieshou);
            }

            tbReceivedCount.Text = (Convert.ToInt32(tbReceivedCount.Text) + ReceivedData_jieshou.Length).ToString();//收数记录

            if (cb16Display.Checked)//数据接收区是否按16进制显示
                tbReceivedData.Text = Methods.ByteTo16Str(receivedDatas.ToArray());
            else//按ASCII码显示
                tbReceivedData.Text = Encoding.Default.GetString(receivedDatas.ToArray());
            sp_jieshou.DiscardInBuffer();//丢弃接收缓冲区数据

        }

        //发送船机串口数据
        private void DataSend_fasong()
        {
            try
            {
                if (cb16Send.Checked)//是否按16进制发送
                {
                    byte[] hexBytes = Methods._16strToHex(tbSendData16);
                    sp_fasong.Write(hexBytes, 0, hexBytes.Length);
                    tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + hexBytes.Length).ToString();

                }
                else
                {
                    sp_fasong.WriteLine(tbSendDataStr);
                    tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + tbSendDataStr.Length).ToString();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("2" + ex.Message.ToString());
                return;
            }
        }

        //发送姿态串口数据，给匿名上位机显示波形
        private void DataSend_zitai(byte[] ReceivedData_jieshou)
        {
            byte[] senser_zhen = new byte[23];
            try
            {
                senser_zhen = Methods.senser_zhen_tran(ReceivedData_jieshou);//调用帧转换方法，把收到的角加速度、速度信息转换成匿名上位机的帧格式
                sp_zitai.Write(senser_zhen, 0, senser_zhen.Length);
                zitaiSendData.Text = Methods.ByteTo16Str(senser_zhen.ToArray());
                zitaiSendCount.Text = (Convert.ToInt32(zitaiSendCount.Text) + senser_zhen.Length).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("3" + ex.Message.ToString());
                return;
            }
        }
        #endregion

        /// ////////////////////////////////<按键区代码>//////////////////////////////////////////
        #region 

        //发送文本框按键抬起时触发的事件
        private void tbSendData_KeyUp(object sender, KeyEventArgs e)
        {
            if (cb16Send.Checked)
            {
                tbSendData16 = tbSendData.Text.Trim();
            }
            else
            {
                tbSendDataStr = tbSendData.Text;
            }
        }

        //点击读入文件按钮
        private void btnReadFile_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "所有文件(*.*)|*.*";
            //文件筛选器的设定
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Title = "选择文件";
            openFileDialog1.FileName = "";
            openFileDialog1.ShowHelp = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open))
                {
                   
                    byte[] bufferByte = new byte[fs.Length];
                    fs.Read(bufferByte, 0, Convert.ToInt32(fs.Length));
                    
                    sp_fasong.Write(bufferByte, 0, bufferByte.Length);
                    tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + bufferByte.Length).ToString();
                }

            }
        }

        //点击保存数据按钮
        private void btnSaveFile_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "文本文件|*.txt";//对保存对话框选择保存类型 所有文件(*.*)|*.*
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fName = saveFileDialog1.FileName;
                using (FileStream fs = File.Open(fName, FileMode.Append))
                {
                    fs.Write(receivedDatas.ToArray(), 0, receivedDatas.Count);//将收到的数据写入文件
                }
            }
        }

        //点击是否手动控制船体的运动
        private void shoudong_ctrl_CheckedChanged(object sender, EventArgs e)
        {
            if (shoudong_ctrl.Checked)
            {
                KeyPreview = true;
                shipin_ctrl.Checked = true;
            }
            else
            {
                KeyPreview = false;
            }

        }

        //点击数据接收区清空按钮
        private void btnClearReceived_Click(object sender, EventArgs e)
        {
            receivedDatas.Clear();
            tbReceivedData.Text = "";
        }

        //关闭窗口时出发的事件
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(path, false))
                {
                    sw.WriteLine("cbxCOMPort=" + cbxCOMPort.Text);
                    sw.WriteLine("cbxBaudRate=" + portInfo.Baudrate);
                    sw.WriteLine("cbxDataBits=" + portInfo.DataBits);
                    sw.WriteLine("cbxStopBits=" + portInfo.STOPBITS);
                    sw.WriteLine("cbxParity=" + portInfo.PARITY);
                    sw.WriteLine("cb16Display=" + cb16Display.Checked.ToString());
                    sw.WriteLine("tbSpaceTime=" + tbSpaceTime.Text);
                    sw.WriteLine("cb16Send=" + cb16Send.Checked.ToString());
                    sw.WriteLine("tbSendDataStr=" + tbSendDataStr);
                    sw.WriteLine("tbSendData16=" + tbSendData16);
                    sw.WriteLine("zitaiSendData16=" + zitaiSendData16);
                    sp_jieshou.Close();
                    sp_fasong.Close();
                    sp_zitai.Close();
                    sp_shexiangtou.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("1" + ex.Message.ToString());
            }
        }

        //点击是否按16进制显示接收数据
        private void cb16Display_CheckedChanged_1(object sender, EventArgs e)
        {
            if (cb16Display.Checked)
            {
                tbReceivedData.Text = Methods.ByteTo16Str(receivedDatas.ToArray());
            }
            else
            {
                tbReceivedData.Text = Encoding.Default.GetString(receivedDatas.ToArray());
            }

        }

        //点击是否按16进制发送数据
        private void cb16Send_CheckedChanged(object sender, EventArgs e)
        {
            if (cb16Send.Checked)
            {
                tbSendData.Text = tbSendData16;
            }
            else
            {
                tbSendData.Text = tbSendDataStr;
            }
        }

        //发送文本框键盘按键检测
        private void tbSendData_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (cb16Send.Checked)
            {
                //正则匹配
                string pattern = "[0-9a-fA-F]|\b";//\b:退格键,0-9,a-f,A-F
                Match m = Regex.Match(e.KeyChar.ToString(), pattern);
                if (m.Success)
                {
                    if (e.KeyChar != '\b')
                    {
                        if (tbSendData.Text.Length % 3 == 2)
                        {
                            tbSendData.Text += " ";
                            tbSendData.SelectionStart = tbSendData.Text.Length;
                        }
                        e.KeyChar = Convert.ToChar(e.KeyChar.ToString().ToUpper());
                    }
                    e.Handled = false;
                }
                else
                {
                    e.Handled = true;
                }
            }
            else
            {
                e.Handled = false;
            }
        }

        //点击清空数据发送内容
        private void btnClearSend_Click(object sender, EventArgs e)
        {
            tbSendData.Text = "";
            if (cb16Send.Checked)
                tbSendData16 = "";
            else
                tbSendDataStr = "";
        }

        //点击清空姿态发送区内容
        private void zitaiClearData_Click(object sender, EventArgs e)
        {
            zitaiSendData.Text = "";
            zitaiSendCount.Text = "";
        }

        //点击清空计数器数据
        private void btnClearCount_Click(object sender, EventArgs e)
        {
            tbReceivedCount.Text = "0";
            tbSendCount.Text = "0";
        }

        //清空指令计数器
        private void zhiling_clear_Click(object sender, EventArgs e)
        {
            zhiling_jieshou_count.Text = "0";
            hong_zhiling.Text = "";
            xiliezhiling.Text = "";     
        }

        //点击是否设置自动发送
        private void cbAutomaticSend_CheckedChanged(object sender, EventArgs e)
        {
            if (cbAutomaticSend.Checked)
            {
                timer2.Enabled = true;
                timer2.Interval = Convert.ToInt32(tbSpaceTime.Text);
            }
            else
            {
                timer2.Enabled = false;
            }
        }

        //点击是否手动控制区信号定时发送
        private void sd_AutomaticSend_CheckedChanged(object sender, EventArgs e)
        {
            if (sd_AutomaticSend.Checked)
            {
                timer3.Enabled = true;
                timer3.Interval = Convert.ToInt32(sd_SpaceTime.Text);
            }
            else
            {
                timer3.Enabled = false;
            }

        }

        //自动发送时间文本框键盘按键检测
        private void tbSpaceTime_KeyPress(object sender, KeyPressEventArgs e)
        {
            //正则匹配
            string pattern = "[0-9]|\b";
            Match m = Regex.Match(e.KeyChar.ToString(), pattern);
            if (m.Success)
            {
                timer2.Interval = Convert.ToInt32(tbSpaceTime.Text);
                e.Handled = false;
            }
            else
            {
                e.Handled = true;
            }
        }

        //设置串口属性
        private void SetPortProperty()
        {
            sp_jieshou.PortName = recCOMPort.Text.Trim();//设置接收串口名，trim用于去掉多余空格
            sp_fasong.PortName = cbxCOMPort.Text.Trim(); //设置发送串口名，trim用于去掉多余空格
            sp_zitai.PortName = zitaiCOMPort.Text.Trim();
            sp_shexiangtou.PortName = zhilingCOMPort.Text.Trim();

            sp_jieshou.ReadTimeout = 500000;//设置超时时间为500s，单位为毫秒
            sp_fasong.ReadTimeout = 500000;

            sp_jieshou.BaudRate = portInfo.Baudrate;
            sp_fasong.BaudRate = portInfo.Baudrate;

            sp_jieshou.DataBits = portInfo.DataBits;
            sp_fasong.DataBits = portInfo.DataBits;

            sp_jieshou.Parity = portInfo.PARITY;
            sp_jieshou.StopBits = portInfo.STOPBITS;

            sp_fasong.Parity = portInfo.PARITY;
            sp_fasong.StopBits = portInfo.STOPBITS;

            Control.CheckForIllegalCrossThreadCalls = false;//这个类中我们不检查跨线程的调用是否合法(因为.net 2.0以后加强了安全机制,，不允许在winform中直接跨线程访问控件的属性)
                                                            //定义DataReceived事件的委托，当串口收到数据后触发事件

            sp_jieshou.DataReceived += new SerialDataReceivedEventHandler(sp_jieshou_DataReceived);//DataReceived事件触发以后，调用sp_jieshou_DataReceived函数
            sp_shexiangtou.DataReceived += new SerialDataReceivedEventHandler(sp_shexiangtou_DataReceived);//DataReceived事件触发以后，调用sp_jieshou_DataReceived函数
        }

        //点击打开串口按钮
        private void btnOpenCom_Click(object sender, EventArgs e)
        {
            if ((!sp_jieshou.IsOpen) | (!sp_fasong.IsOpen) | (!sp_shexiangtou.IsOpen) | (!sp_zitai.IsOpen))
            {
                if (!isSetProperty)//串口未设置则设置串口属性
                {
                    SetPortProperty();
                    isSetProperty = true;
                }
                sp_jieshou.Open();
                sp_fasong.Open();
                sp_shexiangtou.Close();
                sp_zitai.Open();
                btnOpenCom.Text = "关闭串口";
                DisplayPortState(PortState.打开);


            }
            else//串口已经打开
            {
                try
                {
                    sp_jieshou.Close();
                    sp_zitai.Close();
                    sp_shexiangtou.Close();
                    sp_fasong.Close();
                    isSetProperty = false;
                    btnOpenCom.Text = "打开串口";
                    DisplayPortState(PortState.关闭);
                }
                catch (Exception)
                {
                    MessageBox.Show("关闭串口时发生错误", "错误提示");
                }
            }

        }

        //点击发送，发送船机串口数据
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (tbSendData.Text.Trim() == "")//检测发送数据是否为空
            {
                MessageBox.Show("请输入要发送的数据!", "错误提示");
                return;
            }
            if (sp_fasong.IsOpen)
            {
                DataSend_fasong();
            }
            else
            {
                MessageBox.Show("串口未打开!", "错误提示");
            }
        }

        //设置按键，选择波特率、校验位等
        private void setbutton_Click(object sender, EventArgs e)
        {
            Portsetting ps = new Portsetting();
            ps.Owner = this;
            if (ps.ShowDialog() == DialogResult.OK)
            {
                sp_jieshou.BaudRate = portInfo.Baudrate;
                sp_jieshou.DataBits = portInfo.DataBits;
                sp_jieshou.Parity = portInfo.PARITY;
                sp_jieshou.StopBits = portInfo.STOPBITS;

                sp_zitai.BaudRate = portInfo.Baudrate;
                sp_zitai.DataBits = portInfo.DataBits;
                sp_zitai.Parity = portInfo.PARITY;
                sp_zitai.StopBits = portInfo.STOPBITS;

                sp_shexiangtou.BaudRate = portInfo.Baudrate;
                sp_shexiangtou.DataBits = portInfo.DataBits;
                sp_shexiangtou.Parity = portInfo.PARITY;
                sp_shexiangtou.StopBits = portInfo.STOPBITS;

                sp_fasong.BaudRate = portInfo.Baudrate;
                sp_fasong.DataBits = portInfo.DataBits;
                sp_fasong.Parity = portInfo.PARITY;
                sp_fasong.StopBits = portInfo.STOPBITS;

                this.tbReceivedData.AppendText("\n");
                this.zitaiSendData.AppendText("\n");
                DisplayPortState(PortState.打开);
            }
        }
        #endregion

        /// ////////////////////////////////<控制区代码>//////////////////////////////////////////
        #region 

        //控制区
        byte[] instrunction0 = new byte[1];
        int instrunction = 0x11;
        int l_dangwei = 0;
        int r_dangwei = 0;

        //通过键盘按键对左右电机进行控制
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {

            //右电机加档
            if (e.KeyCode == Keys.O )
            {
                if ((instrunction & 0x0f) <= 0x09)
                {
                    instrunction = instrunction + 0x01;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (r_dangwei < 9)
                {
                    r_dangwei += 1;
                }
                right_dangwei.Text = (r_dangwei).ToString();
            }

            //左电机减档
            if (e.KeyCode == Keys.K )
            {
                if ((instrunction & 0xf0) >= 0x10)
                {
                    instrunction = instrunction - 0x10;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (l_dangwei > -1)
                {
                    l_dangwei -= 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();
            }

            //左电机加档
            if (e.KeyCode == Keys.I )
            {
                if ((instrunction & 0xf0) <= 0x90)//防止一直升档
                {
                    instrunction = instrunction + 0x10;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (l_dangwei < 9)//防止一直升档
                {
                    l_dangwei += 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();//档位显示
            }

            //减档式右转
            if (e.KeyCode == Keys.L )
            {
                if ((instrunction & 0x0f) >= 0x01)//防止一直升档
                {
                    instrunction = instrunction - 0x01;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (r_dangwei > -1)
                {
                    r_dangwei -= 1;
                }
                right_dangwei.Text = (r_dangwei).ToString();
            }
            //前进，均加档
            if (e.KeyCode == Keys.W )
            {
                if ((instrunction & 0xf0) <= 0x90)//防止一直升档
                {
                    instrunction = instrunction + 0x10;
                }
                if ((instrunction & 0x0f) <= 0x09)
                {
                    instrunction = instrunction + 0x01;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (l_dangwei < 9)
                {
                    l_dangwei += 1;
                }
                if (r_dangwei < 9)
                {
                    r_dangwei += 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();
                right_dangwei.Text = (r_dangwei).ToString();
            }

            //后退,均减档
            if (e.KeyCode == Keys.S )
            {
                if ((instrunction & 0xf0) >= 0x10)
                {
                    instrunction = instrunction - 0x10;
                }
                if ((instrunction & 0x0f) >= 0x01)
                {
                    instrunction = instrunction - 0x01;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (l_dangwei > -1)
                {
                    l_dangwei -= 1;
                }
                if (r_dangwei > -1)
                {
                    r_dangwei -= 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();
                right_dangwei.Text = (r_dangwei).ToString();
            }
            //紧急停止
            if (e.KeyCode == Keys.J  )
            {
                instrunction = 0x11;
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                left_dangwei.Text = (0).ToString();
                right_dangwei.Text = (0).ToString();
                l_dangwei = 0;
                r_dangwei = 0;
            }
            //加档以及减档式左拐
            if (e.KeyCode == Keys.A )
            {
                if ((instrunction & 0xf0) >= 0x10)
                {
                    instrunction = instrunction - 0x10;
                }
                if ((instrunction & 0x0f) <= 0x09)
                {
                    instrunction = instrunction + 0x01;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (l_dangwei > -1)
                {
                    l_dangwei -= 1;
                }
                if (r_dangwei < 9)
                {
                    r_dangwei += 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();
                right_dangwei.Text = (r_dangwei).ToString();
            }

            //加档以及减档式右拐
            if (e.KeyCode == Keys.D )
            {
                if ((instrunction & 0x0f) >= 0x01)
                {
                    instrunction = instrunction - 0x01;
                }
                if ((instrunction & 0xf0) <= 0x90)
                {
                    instrunction = instrunction + 0x10;
                }
                instrunction0 = BitConverter.GetBytes(instrunction);
                sp_fasong.Write(instrunction0, 0, 1);

                dongzuoDatas.Add(instrunction0[0]);

                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
                if (r_dangwei > -1)
                {
                    r_dangwei -= 1;
                }
                if (l_dangwei < 9)
                {
                    l_dangwei += 1;
                }
                left_dangwei.Text = (l_dangwei).ToString();
                right_dangwei.Text = (r_dangwei).ToString();
            }


        }
        public byte[] Hong_zhiling;
        public byte[] Xiliezhiling;
        //设计流程化指令,点击设置完后，自动将指令串赋值给zl2 .Zhiling，并确定好间隔时间，把要发的显示在程控指令发送区
        private void zhiling_list_Click(object sender, EventArgs e)
        {

            Hong_zhiling = Methods._16strToHex(hong_zhiling.Text);                 
        }
        //设计系列指令，点击后可以周期性发送
        private void jianru_xilie_Click(object sender, EventArgs e)
        {
            Xiliezhiling= Methods._16strToHex(xiliezhiling.Text);

            if (sp_fasong.IsOpen)
            {
                do  //不要指令用满30个，保持有多余的0空出来作为停止标志
                {
                    sp_fasong.Write(Xiliezhiling, j++, 1);
                    Delay(Convert.ToInt32(zhiling_jiange.Text) / 1000);//延时对应时间
                }
                while (j < Xiliezhiling.Length);
                j = 0;
                             
            }
            else
            {
                MessageBox.Show("串口未打开!", "错误提示");
                return;
            }
        }
        #endregion

        /// ////////////////////////////////<定时器代码>//////////////////////////////////////////
        #region 

        //定时器3，用于定时发送手动控制的状态
        private void timer3_Tick(object sender, EventArgs e)
        {

            if (sp_fasong.IsOpen)
            {
                sp_fasong.Write(instrunction0, 0, 1);
                dongzuoDatas.Add(instrunction0[0]);
                tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + instrunction0.Length).ToString();
            }
            else
            {
                timer3.Enabled = false;
                sd_AutomaticSend.Checked = false;
                MessageBox.Show("串口未打开!", "错误提示");
                return;
            }

        }

        //定时器2，用于刷新串口显示状态
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (sp_fasong.IsOpen)
            {
                DataSend_fasong();
            }
            else
            {
                timer2.Enabled = false;
                cbAutomaticSend.Checked = false;
                MessageBox.Show("串口未打开!", "错误提示");

                return;
            }
            if (tbSendData.Text.Trim() == "")//检测发送数据是否为空
            {
                timer2.Enabled = false;
                cbAutomaticSend.Checked = false;
                MessageBox.Show("请输入要发送的数据!", "错误提示");
                return;
            }
        }
        //定时器1，用于刷新当前时间
        private void timer1_Tick(object sender, EventArgs e)
        {
            toolStripStatusLabel3.Text = DateTime.Now.ToString();
        }

        #endregion

        /// ////////////////////////////////<读写指令文件代码>////////////////////////////////////
        #region 
        //保存动作
        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "文本文件|*.txt";//对保存对话框选择保存类型 所有文件(*.*)|*.*
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string fName = saveFileDialog1.FileName;
                using (FileStream fs = File.Open(fName, FileMode.Append))
                {
                    fs.Write(dongzuoDatas.ToArray(), 0, dongzuoDatas.Count);//将收到的数据写入文件
                }
            }
        }
        int r = 0;
        //读入动作
        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "文本文件|*.txt";
            //文件筛选器的设定
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.Title = "选择文件";
            openFileDialog1.FileName = "";
            openFileDialog1.ShowHelp = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (FileStream fs = new FileStream(openFileDialog1.FileName, FileMode.Open))
                {

                    byte[] bufferByte = new byte[fs.Length];
                    fs.Read(bufferByte, 0, Convert.ToInt32(fs.Length));
                    if (sp_fasong.IsOpen)
                    {
                        do
                        {
                            sp_fasong.Write(bufferByte, r++, 1);
                            Delay(Convert.ToInt32(duzhiling_jiange.Text) / 1000);//延时对应时间
                        }
                        while (r < bufferByte.Length);
                        r = 0;
                    }
                    else
                    {
                        MessageBox.Show("串口未打开!", "错误提示");
                        return;
                    }

                    tbSendCount.Text = (Convert.ToInt32(tbSendCount.Text) + bufferByte.Length).ToString();
                }

            }
        }
        #endregion

    }
}

 
